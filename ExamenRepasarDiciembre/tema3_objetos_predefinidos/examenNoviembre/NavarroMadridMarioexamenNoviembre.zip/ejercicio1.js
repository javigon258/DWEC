/**
 * 
 * @author Mario Navarro Madrid
 */

{
    function init() {
        leerStorage();
        mostrarContador();
        document.getElementById("resetear").addEventListener("click",reset);
        document.getElementById("atras").href = "index.html";
        
    }

    function reset() {
        localStorage.setItem("contador","reset");
        document.getElementById("info").innerHTML = `
            RESETEADO
        `
    }

    function leerStorage() {
        if(localStorage.getItem("contador")==null || localStorage.getItem("contador")=="reset"){
            localStorage.setItem("contador",0);
        }else{
            let contador = localStorage.getItem("contador");
            contador++;
            localStorage.setItem("contador",contador);
        }

    }

    function mostrarContador() {
        let mensaje;
        if(localStorage.getItem("contador")==="0"){
            mensaje = `
                Bienvenido a mi humilde rinconcito. Acomodate y pilla una bebida. Espero que vuelvas pronto.
            `
        }
        else if(localStorage.getItem("contador")==="1")
            mensaje = `
                ¿De nuevo por aquí? Es la segunda vez que vienes, toma unos anacardos.
            `
        else{
            mensaje = `
            ¿Te ha gustado el sitio eh? Es la vez número ${localStorage.getItem("contador")} que vienes.
        `
        }
        document.getElementById("info").innerHTML = mensaje;
    }

    document.addEventListener("DOMContentLoaded",init);

}