{

    function init() {
        document.getElementById("a1").href = "ejercicio1.html";
        document.getElementById("a2").href = "ejercicio2.html";
    }


    document.addEventListener("DOMContentLoaded",init);
}