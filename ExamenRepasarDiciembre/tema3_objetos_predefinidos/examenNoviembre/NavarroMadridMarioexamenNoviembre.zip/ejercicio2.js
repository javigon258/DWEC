{
    function init() {
        regex = /^([a-zA-ZÁÉÍÓÚáéíúó]\s?){1,}(,)(\s?[a-zA-ZÁÉÍÓÚáéíúó]){1,}$/
        document.getElementById("name").addEventListener("blur",checkNombre);
        document.getElementById("a").href="index.html";
    }

    function checkNombre() {
        let nombre = document.getElementById("name").value;
        if(regex.test(nombre)){
            arrayRegex = regex.exec(nombre);
            document.getElementById("nombre").innerHTML += arrayRegex[0];
            document.getElementById("apellido").innerHTML += arrayRegex[2];
            document.getElementById("error").innerHTML = "";
        }else{
            document.getElementById("error").innerHTML = "Error. Formato correcto: Cuadrado Perfecto, Anacleto";
        }
    }

    

    document.addEventListener("DOMContentLoaded",init);
}