{
    let mensaje;
    let btnReset;
    let btnRecargarPagina;
    //let atras;

    function init() {
      mensaje = document.getElementById("mensaje");
      btnReset = document.getElementById("btnReset");
      btnRecargarPagina = document.getElementById("btnRecargarPagina");
     // atras = document.getElementById("atras");
  
      funcionalidad();
  
      btnReset.addEventListener("click", resetContador);
      btnRecargarPagina.addEventListener("click", recargarPagina);
  
     /* atras.addEventListener("click", ev => {
        ev.preventDefault;
        history.back();
      });*/
    }
  
    function generaMensaje(contador) {
      if (contador !== null) {
        if (contador === "1") {
          mensaje.textContent = 'Bienvenido a mi humilde morada. Esta es la primera vez que entras. Espero que vuelvas';
        } else if (contador === "2") {
          mensaje.textContent = 'Hola de nuevo. Ya estas aquí por segunda vez. ¿Volveremos a vernos?. ';
        } else {
          mensaje.innerHTML = 'Ya empiezas a ser pesado. Esta es la vez número <b>'
              + parseInt(contador)+ '</b> que entras. Sigue con tus cosas.';
        }
      }
    }
  
    function funcionalidad() {
      if (localStorage.getItem("contador") === null) {
        localStorage.setItem("contador", 0);
        generaMensaje(localStorage.getItem("contador"));
      } else {
        localStorage.setItem("contador", parseInt(localStorage.getItem("contador")) + 1 );
        generaMensaje(localStorage.getItem("contador"));
        //localStorage.clear();
      }
  
      console.log(localStorage.getItem("contador"));
    }
  
    function resetContador() {
      if (localStorage.getItem("contador") !== null) {
        localStorage.setItem("contador", 0);
        mensaje.innerHTML = '<b>Reseteado</b>';
      }
    }
  
    function recargarPagina() {  
      location.reload();
    }
    document.addEventListener("load", init);
}